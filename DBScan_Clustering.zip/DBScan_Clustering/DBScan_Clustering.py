#!/usr/bin/env python3
# dbscan_pipeline.py

"""
Clean DBSCAN Pipeline (No Synthetic Data)
- Load CSV
- Auto-estimate eps using k-distance elbow
- Optional tuning
- Apply DBSCAN
- Visualize & Save output
"""

from typing import Optional, Dict, Any
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.cluster import DBSCAN
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import NearestNeighbors
from sklearn.metrics import silhouette_score
import warnings

warnings.filterwarnings("ignore")
sns.set_style("darkgrid")
plt.rcParams["figure.figsize"] = (12, 6)

print("✅ DBSCAN Pipeline Loaded")

# Utility: geometric elbow detection
def _find_elbow(distances: np.ndarray) -> int:
    """Find elbow in a sorted curve using max perpendicular distance."""
    if len(distances) < 3:
        return 0
    p1 = np.array([0, distances[0]])
    p2 = np.array([len(distances) - 1, distances[-1]])
    line = p2 - p1
    unit = line / np.linalg.norm(line)

    idx = np.arange(len(distances))
    pts = np.c_[idx, distances]
    proj = np.dot(pts - p1, unit)
    proj_pts = np.outer(proj, unit) + p1
    d = np.linalg.norm(pts - proj_pts, axis=1)
    return int(np.argmax(d))

# 1. Load CSV
def load_data(filepath: str) -> pd.DataFrame:
    """Load user-provided CSV only (no synthetic data)."""
    df = pd.read_csv(filepath)
    print(f"📥 Loaded CSV: {df.shape[0]} rows, {df.shape[1]} columns")
    return df

# 2. Auto-estimate eps + scaling
def estimate_params(X: np.ndarray, k=4, plot=True) -> Dict[str, Any]:
    scaler = StandardScaler()
    Xs = scaler.fit_transform(X)

    nbrs = NearestNeighbors(n_neighbors=k).fit(Xs)
    distances = np.sort(nbrs.kneighbors(Xs)[0][:, k - 1])
    elbow = _find_elbow(distances)

    eps_ = float(distances[elbow])
    min_samples_ = max(3, 2 * X.shape[1])

    print("\n🎯 Estimated Parameters")
    print(f"- eps: {eps_:.4f}")
    print(f"- min_samples: {min_samples_}")

    if plot:
        plt.plot(distances)
        plt.scatter(elbow, distances[elbow], color="red", s=40)
        plt.axhline(eps_, color="red", ls="--")
        plt.title("k-distance Graph")
        plt.show()

    return {"eps": eps_, "min_samples": min_samples_, "X_scaled": Xs, "scaler": scaler}

# 3. Apply DBSCAN
def apply_dbscan(Xs: np.ndarray, eps: float, min_samples: int):
    model = DBSCAN(eps=eps, min_samples=min_samples)
    labels = model.fit_predict(Xs)

    n_clusters = len(set(labels) - {-1})
    noise = np.sum(labels == -1)

    print("\n📊 DBSCAN Results")
    print(f"- Clusters: {n_clusters}")
    print(f"- Noise: {noise} ({noise / len(labels) * 100:.1f}%)")

    # silhouette if valid
    try:
        mask = labels != -1
        if len(set(labels[mask])) > 1:
            score = silhouette_score(Xs[mask], labels[mask])
            print(f"- Silhouette Score: {score:.4f}")
    except:
        pass

    return model, labels, n_clusters, noise

# 4. Visualization
def visualize(Xs, labels, eps=None, min_samples=None):
    cmap = plt.get_cmap("tab20")

    for i, lab in enumerate(np.unique(labels)):
        mask = labels == lab
        color = "gray" if lab == -1 else cmap(i)
        plt.scatter(Xs[mask, 0], Xs[mask, 1], s=25, alpha=0.8, c=[color])

    title = "DBSCAN Clusters"
    if eps:
        title += f" | eps={eps:.3f}, min_samples={min_samples}"

    plt.title(title)
    plt.show()

# 5. Full DBSCAN Pipeline
def run_dbscan(
    filepath: str,
    auto_tune: bool = False,
    output_csv: str = "dbscan_results.csv",
    plot: bool = True,
):
    print("\n🚀 Running DBSCAN Pipeline")

    # Load only user data
    df = load_data(filepath)

    numeric_cols = df.select_dtypes(include=np.number).columns.tolist()
    if len(numeric_cols) < 2:
        raise ValueError("Need at least 2 numerical columns!")

    X = df[numeric_cols].values
    est = estimate_params(X, plot=plot)

    eps, min_s = est["eps"], est["min_samples"]

    model, labels, n_clusters, noise = apply_dbscan(est["X_scaled"], eps, min_s)

    if plot:
        visualize(est["X_scaled"], labels, eps, min_s)

    # save results
    df_out = df.copy()
    df_out["Cluster"] = labels
    df_out["Is_Noise"] = labels == -1
    df_out.to_csv(output_csv, index=False)
    print(f"💾 Saved results to: {output_csv}")

    return {
        "model": model,
        "labels": labels,
        "n_clusters": n_clusters,
        "noise": noise,
        "eps": eps,
        "min_samples": min_s,
        "scaled_data": est["X_scaled"],
    }


# CLI
if __name__ == "__main__":
    run_dbscan(
        filepath="Mall_Customers.csv",   #Replace with your file
        auto_tune=False,
        output_csv="dbscan_results.csv",
        plot=True
    )
