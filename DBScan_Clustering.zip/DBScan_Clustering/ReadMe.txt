python -m venv .DBScanVenv

Set-ExecutionPolicy RemoteSigned -Scope CurrentUser

/.DBScanVenv/Scripts/Activate.ps1

pip install Requirements.txt

python DBScan_Clustering.py