import pandas as pd

url = 'https://raw.githubusercontent.com/numenta/NAB/master/data/artificialWithAnomaly/art_daily_flatmiddle.csv'

df = pd.read_csv(url)
df.to_csv("Anomaly_Time_Series.csv", index=False)
print("Data as been save")