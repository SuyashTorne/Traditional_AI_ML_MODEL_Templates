"""
Isolation Forest Anomaly Detection Pipeline
Clean, modular implementation with comprehensive visualization and evaluation
Fixed: robust 1-D PCA handling, scaler fixes, consistent results fields, safer contamination estimation
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler, RobustScaler, PowerTransformer, MinMaxScaler, QuantileTransformer
from sklearn.decomposition import PCA
from sklearn.metrics import roc_curve, auc, confusion_matrix
from sklearn.neighbors import LocalOutlierFactor, NearestNeighbors
from scipy import stats
import joblib
import warnings
warnings.filterwarnings('ignore')

# Visualization setup
plt.style.use('seaborn-v0_8-darkgrid')
sns.set_palette("tab10")
plt.rcParams['figure.figsize'] = [14, 8]
plt.rcParams['font.size'] = 12

print("✅ Isolation Forest Anomaly Detection Package Loaded")


class IsolationForestAnomalyDetector:
    """Main class for Isolation Forest anomaly detection pipeline"""

    def __init__(self, random_state=42):
        self.random_state = random_state
        self.model = None
        self.scaler = None
        self.results = {}

    def load_data(self, filepath=None, features=None, contamination=0.1):
        """Load data from file or generate synthetic data"""
        true_labels = None
        if filepath:
            df = pd.read_csv(filepath)
            print(f"✅ Loaded: {df.shape[0]} rows, {df.shape[1]} columns")

            # Try to extract obvious label columns
            label_cols = [col for col in df.columns
                          if col.lower() in ['label', 'target', 'anomaly', 'outlier']]
            if label_cols:
                true_labels = df[label_cols[0]].copy()
                df = df.drop(columns=label_cols[0])
        else:
            df, true_labels = self._generate_synthetic_data(contamination)

        # Select features (or use provided list)
        features = features or self._select_features(df)
        X = df[features].copy()
        X = self._handle_missing_values(X)

        return df, X, features, true_labels

    def _generate_synthetic_data(self, contamination):
        """Generate synthetic data with anomalies"""
        np.random.seed(self.random_state)
        n_normal, n_anomalies = 1000, int(1000 * contamination)

        # Normal data
        normal = np.random.randn(n_normal, 2)
        normal[:, 1] = 0.7 * normal[:, 0] + 0.3 * normal[:, 1]
        normal = normal * [10, 5] + [50, 50]

        # Anomalies
        anomalies = np.vstack([
            [[150, 150], [200, 50], [50, 200]],
            np.random.randn(max(1, n_anomalies // 2), 2) * [2, 10] + [30, 150],
            np.random.randn(max(1, n_anomalies // 2), 2) * 5 + [100, 100]
        ])

        X = np.vstack([normal, anomalies])
        labels = np.ones(len(X))
        labels[len(normal):] = -1

        # Create DataFrame with additional features
        df = pd.DataFrame(X, columns=['Feature_1', 'Feature_2'])
        df['Feature_3'] = df['Feature_1'] * 0.3 + np.random.randn(len(df)) * 5
        df['Feature_4'] = np.log(np.abs(df['Feature_2']) + 1) + np.random.randn(len(df)) * 2

        print(f"✅ Generated synthetic data: {len(normal)} normal, {len(anomalies)} anomalies")
        return df, labels

    def _select_features(self, df):
        """Automatically select numerical features for anomaly detection"""
        numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
        exclude_keywords = ['label', 'target', 'anomaly', 'outlier', 'id', 'index']
        features = [col for col in numeric_cols
                    if not any(kw in col.lower() for kw in exclude_keywords)]

        if len(features) > 20:
            variances = df[features].var().sort_values(ascending=False)
            features = variances.head(20).index.tolist()

        if len(features) == 0:
            raise ValueError("No numeric features found for anomaly detection.")

        print(f"🎯 Selected {len(features)} features: {features}")
        return features

    def _handle_missing_values(self, X):
        """Handle missing values in feature matrix"""
        if X.isnull().sum().sum() == 0:
            return X

        print("🔧 Handling missing values...")
        for col in X.columns:
            missing_pct = X[col].isnull().sum() / len(X)
            if missing_pct < 0.05:
                X[col].fillna(X[col].median(), inplace=True)
            elif missing_pct < 0.3:
                X[col].fillna(method='ffill', inplace=True)
                X[col].fillna(method='bfill', inplace=True)
            else:
                X[col].fillna(-999, inplace=True)
        return X

    def scale_data(self, X, method='robust', handle_skew=True):
        """Scale and transform features"""
        X_scaled = X.copy()

        if handle_skew:
            skewed = X.apply(lambda x: abs(stats.skew(x.dropna())) > 1)
            skewed_cols = skewed[skewed].index.tolist()

            for col in skewed_cols:
                try:
                    # Box-Cox requires strictly positive values
                    if (X[col] > 0).all():
                        pt = PowerTransformer(method='box-cox')
                        X_scaled[col] = pt.fit_transform(X[[col]])
                    else:
                        pt = PowerTransformer(method='yeo-johnson')
                        X_scaled[col] = pt.fit_transform(X[[col]])
                except Exception:
                    # fallback to log1p or ranking transform
                    try:
                        X_scaled[col] = np.log1p(X[col] - X[col].min() + 1)
                    except Exception:
                        X_scaled[col] = X[col]

        scalers = {
            'standard': StandardScaler(),
            'robust': RobustScaler(quantile_range=(25, 75)),
            'minmax': MinMaxScaler(),
            'quantile': QuantileTransformer(output_distribution='normal')
        }

        if method in scalers:
            self.scaler = scalers[method]
            X_scaled = pd.DataFrame(
                self.scaler.fit_transform(X_scaled),
                columns=X.columns, index=X.index
            )
            print(f"✅ Applied {method} scaling")
        else:
            print(f"⚠️ Scaling method '{method}' not recognized — skipping scaling.")

        return X_scaled

    def estimate_contamination(self, X, method='auto'):
        """Estimate optimal contamination rate"""
        if method == 'auto':
            # Guard small datasets
            n_samples = len(X)
            n_neighbors = min(20, max(2, n_samples - 1))

            try:
                lof = LocalOutlierFactor(n_neighbors=n_neighbors, contamination='auto')
                lof_labels = lof.fit_predict(X)
                lof_cont = (lof_labels == -1).sum() / len(lof_labels)
            except Exception:
                lof_cont = 0.01

            # Distance-based
            try:
                nbrs = NearestNeighbors(n_neighbors=min(5, n_samples - 1)).fit(X)
                distances, _ = nbrs.kneighbors(X)
                avg_dist = distances.mean(axis=1)
                Q1, Q3 = np.percentile(avg_dist, [25, 75])
                dist_cont = (avg_dist > Q3 + 1.5 * (Q3 - Q1)).sum() / len(avg_dist)
            except Exception:
                dist_cont = 0.01

            estimated = max(0.001, min(0.2, (lof_cont + dist_cont) / 2))
            print(f"🎯 Estimated contamination: {estimated:.3f}")
            return estimated

        return 0.1  # Default

    def fit(self, X, contamination=0.1, n_estimators=100, **kwargs):
        """Train Isolation Forest model"""
        self.model = IsolationForest(
            contamination=contamination,
            n_estimators=n_estimators,
            max_samples=min(256, len(X)),
            max_features=1.0,
            random_state=self.random_state,
            n_jobs=-1,
            **kwargs
        )

        self.model.fit(X)
        scores = self.model.decision_function(X)
        predictions = self.model.predict(X)
        anomaly_scores = -scores  # Higher = more anomalous
        threshold = np.percentile(anomaly_scores, 100 * (1 - contamination))

        n_anomalies = int((predictions == -1).sum())

        self.results.update({
            'predictions': predictions,
            'anomaly_scores': anomaly_scores,
            'threshold': threshold,
            'n_anomalies': n_anomalies
        })

        print(f"✅ Trained on {len(X)} samples, detected {n_anomalies} anomalies")

        return self

    def evaluate(self, true_labels=None):
        """Evaluate model performance"""
        if true_labels is None:
            return self._unsupervised_evaluation()
        return self._supervised_evaluation(true_labels)

    def _supervised_evaluation(self, true_labels):
        """Evaluation with ground truth labels"""
        from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

        y_true = np.array(true_labels)
        # Normalize label scheme: if labels are {1, -1} map -1 -> 1 (anomaly)
        if set(np.unique(y_true)) == {1, -1}:
            y_true = (y_true == -1).astype(int)
        else:
            y_true = y_true.astype(int)

        y_pred = (self.results['predictions'] == -1).astype(int)

        metrics = {
            'accuracy': accuracy_score(y_true, y_pred),
            'precision': precision_score(y_true, y_pred, zero_division=0),
            'recall': recall_score(y_true, y_pred, zero_division=0),
            'f1': f1_score(y_true, y_pred, zero_division=0)
        }

        print("\n📊 Supervised Evaluation:")
        for name, value in metrics.items():
            print(f"  {name.capitalize()}: {value:.4f}")

        # ROC curve if scores are available
        if 'anomaly_scores' in self.results:
            try:
                fpr, tpr, _ = roc_curve(y_true, self.results['anomaly_scores'])
                metrics['roc_auc'] = auc(fpr, tpr)
                print(f"  ROC AUC: {metrics['roc_auc']:.4f}")
            except Exception:
                pass

        return metrics

    def _unsupervised_evaluation(self):
        """Evaluation without ground truth"""
        scores = np.asarray(self.results.get('anomaly_scores'))
        metrics = {
            'n_anomalies': int((self.results['predictions'] == -1).sum()),
            'anomaly_pct': int((self.results['predictions'] == -1).sum()) / len(self.results['predictions']),
            'score_stats': {
                'mean': float(scores.mean()),
                'std': float(scores.std()),
                'skew': float(stats.skew(scores)),
                'kurtosis': float(stats.kurtosis(scores))
            }
        }

        print("\n📊 Unsupervised Evaluation:")
        print(f"  Anomalies detected: {metrics['n_anomalies']} ({metrics['anomaly_pct']*100:.1f}%)")

        return metrics

    def visualize(self, X, features, true_labels=None):
        """Create comprehensive visualizations"""
        fig, axes = plt.subplots(2, 3, figsize=(18, 12))
        axes = axes.flatten()

        # 1. Score distribution
        axes[0].hist(self.results['anomaly_scores'], bins=50, alpha=0.7, edgecolor='black')
        axes[0].axvline(self.results['threshold'], color='red', linestyle='--', label='Threshold')
        axes[0].set_title('Anomaly Score Distribution')
        axes[0].set_xlabel('Anomaly Score')
        axes[0].set_ylabel('Frequency')
        axes[0].legend()
        axes[0].grid(alpha=0.3)

        # 2. PCA visualization (handle 1D gracefully)
        X_vals = X.copy()
        if X_vals.shape[1] >= 2:
            try:
                pca = PCA(n_components=2, random_state=self.random_state)
                X_pca = pca.fit_transform(X_vals)
                var_exp = pca.explained_variance_ratio_
            except Exception:
                # fallback: take first two cols or pad
                arr = X_vals.values
                if arr.shape[1] == 1:
                    X_pca = np.hstack([arr, np.zeros((arr.shape[0], 1))])
                    var_exp = [1.0, 0.0]
                else:
                    X_pca = arr[:, :2]
                    var_exp = [0.5, 0.5]
        else:
            # 1-D case: use original values as single component
            arr = X_vals.values.reshape(-1, 1)
            X_pca = arr
            var_exp = [1.0]

        colors = ['green' if p == 1 else 'red' for p in self.results['predictions']]

        if X_pca.shape[1] > 1:
            axes[1].scatter(X_pca[:, 0], X_pca[:, 1], c=colors, alpha=0.6, s=30)
            try:
                axes[1].set_xlabel(f'PC1 ({var_exp[0]*100:.1f}%)')
                axes[1].set_ylabel(f'PC2 ({var_exp[1]*100:.1f}%)')
            except Exception:
                axes[1].set_xlabel('PC1')
                axes[1].set_ylabel('PC2')
            axes[1].set_title('Anomalies in PCA Space')
            axes[1].grid(alpha=0.3)
        else:
            axes[1].scatter(range(len(X_pca)), X_pca[:, 0], c=colors, alpha=0.6, s=30)
            axes[1].set_xlabel('Index')
            axes[1].set_ylabel('Feature Value')
            axes[1].set_title('Anomalies (1D Feature)')
            axes[1].grid(alpha=0.3)

        # 3. Feature importance (simple mean-diff)
        if X.shape[1] > 0:
            anomaly_mask = (self.results['predictions'] == -1)
            if anomaly_mask.any():
                feature_diffs = []
                for i, col in enumerate(features):
                    try:
                        diff = abs(X.iloc[anomaly_mask, i].mean() - X.iloc[~anomaly_mask, i].mean())
                    except Exception:
                        diff = 0.0
                    feature_diffs.append((col, diff))

                feature_diffs.sort(key=lambda x: x[1], reverse=True)
                top_features = [x[0] for x in feature_diffs[:5]]
                top_diffs = [x[1] for x in feature_diffs[:5]]

                axes[2].barh(range(len(top_features)), top_diffs)
                axes[2].set_yticks(range(len(top_features)))
                axes[2].set_yticklabels(top_features)
                axes[2].set_xlabel('Mean Difference')
                axes[2].set_title('Top Features for Anomaly Detection')
                axes[2].invert_yaxis()
            else:
                axes[2].text(0.5, 0.5, 'No anomalies to calculate feature differences', ha='center')
                axes[2].axis('off')
        else:
            axes[2].axis('off')

        # 4. Score vs prediction
        try:
            axes[3].boxplot([
                self.results['anomaly_scores'][self.results['predictions'] == 1],
                self.results['anomaly_scores'][self.results['predictions'] == -1]
            ], labels=['Normal', 'Anomaly'], patch_artist=True)
            axes[3].set_ylabel('Anomaly Score')
            axes[3].set_title('Score Distribution by Prediction')
            axes[3].grid(alpha=0.3, axis='y')
        except Exception:
            axes[3].axis('off')

        # 5. True vs Predicted (if available)
        if true_labels is not None:
            try:
                y_true = np.array(true_labels)
                if set(np.unique(y_true)) == {1, -1}:
                    y_true = (y_true == -1).astype(int)
                else:
                    y_true = y_true.astype(int)

                y_pred = (self.results['predictions'] == -1).astype(int)
                cm = confusion_matrix(y_true, y_pred)
                sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=axes[4])
                axes[4].set_title('Confusion Matrix')
                axes[4].set_xlabel('Predicted')
                axes[4].set_ylabel('Actual')
            except Exception:
                axes[4].axis('off')
        else:
            axes[4].text(0.5, 0.5, 'No ground truth available', ha='center')
            axes[4].axis('off')

        # 6. Cumulative distribution
        try:
            sorted_scores = np.sort(self.results['anomaly_scores'])
            cumulative = np.arange(1, len(sorted_scores) + 1) / len(sorted_scores)
            axes[5].plot(sorted_scores, 1 - cumulative, linewidth=2)
            axes[5].axvline(self.results['threshold'], color='red', linestyle='--')
            axes[5].set_xlabel('Anomaly Score')
            axes[5].set_ylabel('Fraction with Higher Score')
            axes[5].set_title('Complementary CDF')
            axes[5].grid(alpha=0.3)
        except Exception:
            axes[5].axis('off')

        plt.tight_layout()
        plt.show()

    def get_anomaly_report(self, df, features):
        """Generate comprehensive anomaly report"""
        report_df = df.copy()
        report_df['Anomaly_Score'] = self.results['anomaly_scores']
        report_df['Is_Anomaly'] = (self.results['predictions'] == -1)
        report_df['Anomaly_Rank'] = report_df['Anomaly_Score'].rank(ascending=False).astype(int)

        # Add scaled feature values (if scaler is available)
        if self.scaler is not None:
            try:
                scaled_vals = self.scaler.transform(report_df[features])
                scaled_df = pd.DataFrame(scaled_vals, columns=[f'{c}_scaled' for c in features], index=report_df.index)
                report_df = pd.concat([report_df, scaled_df], axis=1)
            except Exception:
                # fallback: copy original
                for feature in features:
                    report_df[f'{feature}_scaled'] = report_df[feature]
        else:
            for feature in features:
                report_df[f'{feature}_scaled'] = report_df[feature]

        return report_df.sort_values('Anomaly_Score', ascending=False)


def run_pipeline(filepath=None, features=None, business_context='fraud_detection'):
    """Complete pipeline execution"""
    print(f"🚀 Starting {business_context} Anomaly Detection Pipeline")
    print("=" * 60)

    # Initialize detector
    detector = IsolationForestAnomalyDetector(random_state=42)

    # 1. Load data
    df, X, selected_features, true_labels = detector.load_data(
        filepath=filepath,
        features=features
    )

    # 2. Scale data
    X_scaled = detector.scale_data(X, method='robust', handle_skew=True)

    # 3. Estimate contamination
    contamination = detector.estimate_contamination(X_scaled, method='auto')

    # 4. Train model
    detector.fit(X_scaled, contamination=contamination, n_estimators=100)

    # 5. Evaluate
    metrics = detector.evaluate(true_labels)

    # 6. Visualize
    detector.visualize(X_scaled, selected_features, true_labels)

    # 7. Generate report
    report = detector.get_anomaly_report(df, selected_features)

    # Save results
    results = {
        'model': detector.model,
        'scaler': detector.scaler,
        'results': detector.results,
        'features': selected_features,
        'metrics': metrics,
        'report': report
    }

    joblib.dump(results, 'anomaly_detection_results.pkl')
    report.to_csv('anomaly_report.csv', index=False)

    print(f"\n💾 Results saved:")
    print(f"  - Model: anomaly_detection_results.pkl")
    print(f"  - Report: anomaly_report.csv")

    n_anomalies = results['results'].get('n_anomalies', (results['results']['predictions'] == -1).sum())

    print(f"\n💡 {business_context.upper()} INSIGHTS:")
    print(f"  Detected {n_anomalies} anomalies ({n_anomalies/len(report)*100:.1f}%)")
    print(f"  Threshold: {results['results']['threshold']:.3f}")

    if isinstance(metrics, dict) and 'accuracy' in metrics:
        print(f"  Accuracy: {metrics.get('accuracy', np.nan):.3f}, F1: {metrics.get('f1', np.nan):.3f}")

    return results


if __name__ == "__main__":
    # Quick demo with the provided raw link or use None for synthetic
    raw_link = "https://raw.githubusercontent.com/numenta/NAB/master/data/artificialWithAnomaly/art_daily_flatmiddle.csv"

    results = run_pipeline(
        filepath=raw_link,  # set to None to use synthetic data
        business_context='fraud_detection'
    )

    print("\n" + "=" * 60)
    print("🎉 Pipeline completed successfully!")
    print("=" * 60)
