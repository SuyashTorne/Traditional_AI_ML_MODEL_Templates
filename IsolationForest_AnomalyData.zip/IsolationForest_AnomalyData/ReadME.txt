python -m venv .IsoForVenv

Set-ExecutionPolicy RemoteSigned -Scope CurrentUser 

/.IsoForVenv/Scripts/Activate.ps1

pip install requirements.txt

Python Isolation_Forest.py