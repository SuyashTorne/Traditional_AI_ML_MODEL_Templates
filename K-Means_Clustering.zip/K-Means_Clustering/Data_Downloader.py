import pandas as pd

url = "https://raw.githubusercontent.com/dphi-official/Datasets/master/Mall_Customers.csv"
df = pd.read_csv(url)
df.to_csv("Mall_Customers.csv", index=False)
print("Data has been save")