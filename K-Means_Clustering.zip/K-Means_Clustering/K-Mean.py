import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
import joblib

warnings.filterwarnings('ignore')
sns.set_style('darkgrid')
plt.rcParams['figure.figsize'] = (12, 6)

# --------------------------
# 1. DATA PREPARATION
# --------------------------
def load_data(filepath, features=None):
    """
    Load real-life CSV data.
    Args:
        filepath: str, path to CSV file
        features: list, columns to use for clustering (numeric only recommended)
    Returns:
        df: full dataframe
        X: feature dataframe
        features: final feature columns
    """
    df = pd.read_csv(filepath)
    
    if features is None:
        # Use only numeric columns by default
        features = df.select_dtypes(include=np.number).columns.tolist()
    
    # Fill missing values with median
    X = df[features].fillna(df[features].median())
    
    return df, X, features

# --------------------------
# 2. FEATURE SCALING
# --------------------------
def scale_features(X, method='standard'):
    if method == 'standard':
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)
    else:
        X_scaled = X.values
        scaler = None
    return X_scaled, scaler

# --------------------------
# 3. FIND OPTIMAL K
# --------------------------
def find_k(X_scaled, max_k=10):
    inertia, silhouettes = [], []
    for k in range(2, max_k+1):
        kmeans = KMeans(n_clusters=k, random_state=42, n_init=10).fit(X_scaled)
        inertia.append(kmeans.inertia_)
        silhouettes.append(silhouette_score(X_scaled, kmeans.labels_))
    
    optimal_k = 2 + np.argmax(silhouettes)
    
    # Plot Elbow & Silhouette
    fig, ax = plt.subplots(1,2, figsize=(14,4))
    ax[0].plot(range(2,max_k+1), inertia, 'o-'); ax[0].set_title('Elbow Method')
    ax[1].plot(range(2,max_k+1), silhouettes, 'o-'); ax[1].set_title('Silhouette Score')
    plt.show()
    
    print(f"Optimal K determined: {optimal_k}")
    return optimal_k

# --------------------------
# 4. APPLY K-MEANS
# --------------------------
def run_kmeans(X_scaled, n_clusters):
    kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10).fit(X_scaled)
    labels = kmeans.labels_
    centers = kmeans.cluster_centers_
    print(f"K={n_clusters} | Silhouette={silhouette_score(X_scaled,labels):.3f}")
    return kmeans, labels, centers

# --------------------------
# 5. VISUALIZATION
# --------------------------
def visualize(X_scaled, labels, centers):
    pca = PCA(n_components=2)
    X_pca = pca.fit_transform(X_scaled)
    centers_pca = pca.transform(centers)
    
    plt.scatter(X_pca[:,0], X_pca[:,1], c=labels, cmap='viridis', alpha=0.6)
    plt.scatter(centers_pca[:,0], centers_pca[:,1], c='red', marker='X', s=200)
    plt.xlabel('PCA1'); plt.ylabel('PCA2'); plt.title('Clusters')
    plt.show()

# --------------------------
# 6. PIPELINE
# --------------------------
def kmeans_pipeline(filepath, features=None, scaling='standard', max_k=10):
    df, X, features = load_data(filepath, features)
    X_scaled, scaler = scale_features(X, scaling)
    k = find_k(X_scaled, max_k)
    model, labels, centers = run_kmeans(X_scaled, k)
    visualize(X_scaled, labels, centers)
    
    # Save results
    joblib.dump({'model':model,'scaler':scaler,'labels':labels,'centers':centers}, 'kmeans_results.pkl')
    
    df['Cluster'] = labels
    df.to_csv('clustered_data.csv', index=False)
    print("✅ Pipeline completed and results saved.")
    
    return df, model, labels

# --------------------------
# RUN PIPELINE
# --------------------------
if __name__ == "__main__":
    # Provide your CSV file path here
    filepath = 'Mall_Customers.csv'
    df_clusters, model, labels = kmeans_pipeline(filepath)
