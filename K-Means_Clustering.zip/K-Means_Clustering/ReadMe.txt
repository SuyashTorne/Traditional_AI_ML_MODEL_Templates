python -m venv .KMeanClus

Set-ExecutionPolicy RemoteSigned -Scope CurrentUser

.KMeanClus\Scripts\Activate.ps1

pip install -r Requirements

python K-Mean.py