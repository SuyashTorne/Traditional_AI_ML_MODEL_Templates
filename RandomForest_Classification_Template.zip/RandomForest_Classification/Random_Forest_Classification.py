# CLEAN & CRISP RANDOM FOREST CLASSIFICATION TEMPLATE (PRO VERSION)

import warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, classification_report, roc_auc_score, roc_curve
)
import joblib

# 1. DATA LOADING & PREPARATION

def load_and_prepare_data(filepath=None, target="target", test_size=0.2, seed=42):
    """
    Load dataset, encode categorical features, scale numerical features.
    """

    if filepath:
        df = pd.read_csv(filepath)
        print(f"Loaded dataset: {df.shape}")
    else:
        from sklearn.datasets import load_breast_cancer
        data = load_breast_cancer()
        df = pd.DataFrame(data.data, columns=data.feature_names)
        df[target] = data.target
        print("Loaded example: Breast cancer dataset")

    # Basic cleaning
    df = df.fillna(df.median(numeric_only=True))

    # Split features
    X = df.drop(columns=[target])
    y = df[target]

    # Encode categoricals
    X = pd.get_dummies(X, drop_first=True)

    # Split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, stratify=y, test_size=test_size, random_state=seed
    )

    # Scale numerical only
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    print(f"Train: {X_train.shape}, Test: {X_test.shape}")

    return X_train_scaled, X_test_scaled, y_train, y_test, scaler, X.columns

# 2. TRAIN MODEL

def train_rf(X_train, y_train, tune=False):
    """
    Train random forest with or without hyperparameter tuning.
    """

    if not tune:
        model = RandomForestClassifier(
            n_estimators=150,
            max_features="sqrt",
            random_state=42,
            n_jobs=-1,
            oob_score=True,
        )
        model.fit(X_train, y_train)
        print(f"OOB Score: {model.oob_score_:.4f}")
        return model

    # Hyperparameter Search
    grid = {
        "n_estimators": [100, 200, 300],
        "max_depth": [None, 10, 20],
        "min_samples_split": [2, 5],
        "max_features": ["sqrt", "log2"],
    }

    gs = GridSearchCV(
        RandomForestClassifier(random_state=42),
        grid,
        scoring="accuracy",
        cv=5,
        n_jobs=-1,
        verbose=1,
    )
    gs.fit(X_train, y_train)

    print("Best Params:", gs.best_params_)
    print("Best CV Accuracy:", gs.best_score_)

    return gs.best_estimator_

# 3. MODEL EVALUATION

def evaluate_model(model, X_test, y_test, feature_names):
    """
    Print metrics + plot confusion matrix + feature importance.
    """

    y_pred = model.predict(X_test)
    y_proba = model.predict_proba(X_test)[:, 1] if model.n_classes_ == 2 else None

    # Metrics
    print("\n=== METRICS ===")
    print("Accuracy :", accuracy_score(y_test, y_pred))
    print("Precision:", precision_score(y_test, y_pred, average="weighted"))
    print("Recall   :", recall_score(y_test, y_pred, average="weighted"))
    print("F1 Score :", f1_score(y_test, y_pred, average="weighted"))

    if y_proba is not None:
        print("AUC ROC  :", roc_auc_score(y_test, y_proba))

    print("\n=== CLASSIFICATION REPORT ===")
    print(classification_report(y_test, y_pred))

    # Confusion Matrix
    cm = confusion_matrix(y_test, y_pred)
    plt.figure(figsize=(5,4))
    sns.heatmap(cm, annot=True, cmap="Blues")
    plt.title("Confusion Matrix")
    plt.show()

    # Feature Importance
    fi = pd.DataFrame({
        "feature": feature_names,
        "importance": model.feature_importances_
    }).sort_values("importance", ascending=False)

    plt.figure(figsize=(6,5))
    sns.barplot(y=fi.feature[:15], x=fi.importance[:15])
    plt.title("Top 15 Features")
    plt.show()

    return fi

# 4. PREDICTION

def predict(model, scaler, sample_df):
    """
    Predict class or probabilities for new data.
    """

    if isinstance(sample_df, pd.Series):
        sample_df = sample_df.to_frame().T

    sample_df = pd.get_dummies(sample_df)
    sample_df = sample_df.reindex(model.feature_names_in_, axis=1, fill_value=0)

    sample_scaled = scaler.transform(sample_df)

    return model.predict(sample_scaled)

# 5. SAVE/LOAD MODEL

def save_model(model, scaler, features, name="rf_model.pkl"):
    joblib.dump({
        "model": model,
        "scaler": scaler,
        "features": list(features)
    }, name)
    print(f"Model saved as {name}")


def load_model(name="rf_model.pkl"):
    return joblib.load(name)

# 6. COMPLETE PIPELINE

def run_pipeline(filepath=None, target="target", tune=False):
    X_train, X_test, y_train, y_test, scaler, feat_names = load_and_prepare_data(
        filepath, target
    )

    model = train_rf(X_train, y_train, tune)

    fi = evaluate_model(model, X_test, y_test, feat_names)

    save_model(model, scaler, feat_names)

    return model, fi

# 7. MAIN EXECUTION

if __name__ == "__main__":
    model, fi = run_pipeline(filepath=None, target="target", tune=False)
