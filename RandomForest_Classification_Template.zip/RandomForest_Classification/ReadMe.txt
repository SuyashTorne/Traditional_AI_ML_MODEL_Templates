Python -m venv .RanForClass

Set-ExecutionPolicy RemoteSigned -Scope CurrentUser

& C:\Users\Kabir\OneDrive\Desktop\Model_Template\.RanForClass\Scripts\Activate.ps1

pip install -r Requirements.txt 

python Random_Forest_Classification.py