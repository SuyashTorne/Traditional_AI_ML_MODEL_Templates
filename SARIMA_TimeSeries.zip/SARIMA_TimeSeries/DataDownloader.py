import pandas as pd 

url = "https://raw.githubusercontent.com/ejgao/Time-Series-Datasets/master/Electric_Production.csv"

df = pd.read_csv(url)

df.to_csv("Electric_Production.csv", index=False)

print("Data has been save")