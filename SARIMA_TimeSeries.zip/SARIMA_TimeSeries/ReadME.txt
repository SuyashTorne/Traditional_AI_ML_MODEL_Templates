python -m venv .SarimaVenv

Set-ExecutionPolicy RemoteSigned -Scope CurrentUser

.SarimaVenv/Scripts/Activate.ps1

pip install -r Requirements.txt

python Sarima_TimeSeries.py