#              CLEAN SARIMA TIME SERIES TEMPLATE
#        Auto-ARIMA → Train → Diagnose → Forecast

import pandas as pd
import numpy as np
import warnings
warnings.filterwarnings("ignore")

import matplotlib.pyplot as plt
from sklearn.metrics import (
    mean_absolute_error,
    mean_squared_error,
    mean_absolute_percentage_error
)

from statsmodels.tsa.statespace.sarimax import SARIMAX
import pmdarima as pm
import pickle


# ===============================
# 1. LOAD DATA
# ===============================
def load_timeseries(df=None, filepath=None, date_col='date', value_col='value', freq='D'):
    if df is None:
        df = pd.read_csv(filepath)

    df[date_col] = pd.to_datetime(df[date_col])
    df = df[[date_col, value_col]].sort_values(date_col)
    df.set_index(date_col, inplace=True)
    df = df.asfreq(freq, method='ffill')

    return df[value_col]


# ===============================
# 2. AUTO-IDENTIFY PARAMETERS
# ===============================
def find_sarima_params(series, seasonal_period):
    model = pm.auto_arima(
        series,
        seasonal=True,
        m=seasonal_period,
        trace=False,
        error_action='ignore',
        suppress_warnings=True,
        stepwise=True
    )
    print("AUTO-ARIMA SELECTED:")
    print(model.summary())
    return model.order, model.seasonal_order


# ===============================
# 3. TRAIN MODEL
# ===============================
def train_sarima(series, order, seasonal_order):
    model = SARIMAX(series, order=order, seasonal_order=seasonal_order)
    fitted = model.fit(disp=False)
    print("\nTRAINED SARIMA MODEL SUMMARY:\n", fitted.summary())
    return fitted


# ===============================
# 4. DIAGNOSTICS
# ===============================
def sarima_diagnostics(fitted):
    residuals = fitted.resid

    fig, ax = plt.subplots(1, 2, figsize=(14, 4))
    ax[0].plot(residuals)
    ax[0].set_title("Residuals")

    residuals.plot(kind='hist', bins=30, ax=ax[1], density=True)
    ax[1].set_title("Residual Distribution")

    plt.show()

    print("\nResidual Mean:", residuals.mean())
    print("Residual Std:", residuals.std())


# ===============================
# 5. FORECAST
# ===============================
def sarima_forecast(fitted, steps):
    forecast = fitted.get_forecast(steps)
    y_pred = forecast.predicted_mean
    conf = forecast.conf_int()

    print("\nFORECAST:")
    print(y_pred)

    plt.figure(figsize=(12,4))
    fitted.data.endog.plot(label="History")
    y_pred.plot(label="Forecast")
    plt.fill_between(conf.index, conf.iloc[:,0], conf.iloc[:,1], alpha=0.2)
    plt.legend()
    plt.show()

    return y_pred, conf


# ===============================
# 6. TRAIN / TEST EVALUATION
# ===============================
def evaluate_sarima(series, train_ratio=0.8, seasonal_period=12):
    split = int(len(series) * train_ratio)
    train, test = series[:split], series[split:]

    print(f"\nTrain size: {len(train)}, Test size: {len(test)}")

    order, seasonal_order = find_sarima_params(train, seasonal_period)
    model = train_sarima(train, order, seasonal_order)

    preds = model.get_forecast(len(test)).predicted_mean
    preds.index = test.index  # align

    mae = mean_absolute_error(test, preds)
    rmse = np.sqrt(mean_squared_error(test, preds))
    mape = mean_absolute_percentage_error(test, preds)

    print("\nEVALUATION METRICS:")
    print(f"MAE  : {mae:.3f}")
    print(f"RMSE : {rmse:.3f}")
    print(f"MAPE : {mape:.3f}")

    plt.plot(train, label="Train")
    plt.plot(test, label="Test")
    plt.plot(preds, label="Predicted")
    plt.legend()
    plt.show()

    return model


# ===============================
# 7. MAIN EXECUTION + PICKLE SAVE
# ===============================
if __name__ == "__main__":
    # Load your CSV file here
    series = load_timeseries(filepath="Electric_Production.csv", date_col="DATE", value_col="IPG2211A2N")

    # Train + Evaluate
    model = evaluate_sarima(series, train_ratio=0.8, seasonal_period=12)

    # Save the trained model
    with open("sarima_model.pkl", "wb") as f:
        pickle.dump(model, f)

    print("\nMODEL SAVED AS: sarima_model.pkl")
