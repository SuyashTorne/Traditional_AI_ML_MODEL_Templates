#                 XGBOOST CLASSIFICATION TEMPLATE

import pandas as pd
import numpy as np
from xgboost import XGBClassifier
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, classification_report
import warnings
import pickle 
warnings.filterwarnings("ignore")

# 1. LOAD + CLEAN + ENCODE DATA

def load_and_preprocess(path, target):
    df = pd.read_csv(path)

    if target not in df.columns:
        raise ValueError(f"Target '{target}' not found in dataset.")

    # ---- Drop irrelevant string columns ----
    drop_cols = ["Name", "Ticket", "Cabin"]
    df = df.drop(columns=[c for c in drop_cols if c in df.columns])

    # ---- Label Encode categorical columns ----
    for col in df.select_dtypes(include="object").columns:
        le = LabelEncoder()
        df[col] = le.fit_transform(df[col].astype(str))

    # ---- Handle missing values ----
    df = df.fillna(df.median(numeric_only=True))

    return df

# 2. TRAIN / TEST SPLIT

def split_data(df, target, test_size=0.2, random_state=42):
    X = df.drop(columns=[target])
    y = df[target]

    return train_test_split(
        X, y, test_size=test_size, random_state=random_state, stratify=y
    )

# 3. TRAIN MODEL (WITH OPTIONAL GRID SEARCH)

def train_xgb(X_train, y_train, use_grid=False):
    base_model = XGBClassifier(
        objective="binary:logistic",
        eval_metric="logloss",
        tree_method="hist",
        random_state=42
    )

    if not use_grid:
        base_model.fit(X_train, y_train)
        return base_model

    # ---- Grid Search ----
    param_grid = {
        "max_depth": [3, 5, 7],
        "learning_rate": [0.01, 0.1, 0.3],
        "n_estimators": [100, 200, 300],
        "subsample": [0.7, 1.0],
        "colsample_bytree": [0.7, 1.0]
    }

    grid = GridSearchCV(
        estimator=base_model,
        param_grid=param_grid,
        scoring="f1",
        cv=3,
        n_jobs=-1,
        verbose=0
    )

    grid.fit(X_train, y_train)
    print("Best Params:", grid.best_params_)

    return grid.best_estimator_

# 4. EVALUATE MODEL

def evaluate(model, X_test, y_test):
    preds = model.predict(X_test)

    print("\n=========== MODEL PERFORMANCE ===========")
    print(f"Accuracy : {accuracy_score(y_test, preds):.4f}")
    print(f"Precision: {precision_score(y_test, preds):.4f}")
    print(f"Recall   : {recall_score(y_test, preds):.4f}")
    print(f"F1 Score : {f1_score(y_test, preds):.4f}")
    print("\nClassification Report:\n")
    print(classification_report(y_test, preds))

# 5. FULL PIPELINE

def run_pipeline(path, target, use_grid=False, save=True):
    df = load_and_preprocess(path, target)
    X_train, X_test, y_train, y_test = split_data(df, target)

    model = train_xgb(X_train, y_train, use_grid)
    evaluate(model, X_test, y_test)

    if save:
        save_model(model)

    return model

def save_model(model, filename="xgb_model.pkl"):
    with open(filename, "wb") as f:
        pickle.dump(model, f)
    print(f"\nModel saved successfully as: {filename}")

def load_model(filename="xgb_model.pkl"):
    with open(filename, "rb") as f:
        model = pickle.load(f)
    print(f"Model loaded successfully from: {filename}")
    return model

# RUN DIRECTLY

if __name__ == "__main__":
    model = run_pipeline(
        path="titanic.csv",
        target="Survived",
        use_grid=False,
        save=True
    )
